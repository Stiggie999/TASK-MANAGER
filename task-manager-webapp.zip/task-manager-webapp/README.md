# Task Manager Web App

This is a small browser-based Task Manager app.

## Features
- Home screen with projects
- Open a project to view tasks
- Add, edit, delete, and complete tasks
- Assign tasks to users
- Priority levels: Low, Medium, High, Urgent
- Due date scheduling (date only)
- Mobile-friendly layout
- Saves locally in the browser with localStorage

## Run locally on a computer
You can open `index.html` in a normal browser like Safari, Chrome, or Edge.

## Put it online free
The easiest options are:

### Netlify
1. Go to Netlify.
2. Drag the whole folder or upload the zip file.
3. Netlify will publish it as a website.

### GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `styles.css`, and `app.js`.
3. Turn on GitHub Pages in the repository settings.

### Vercel
1. Import the folder as a static site.
2. Deploy.

## Files
- `index.html` — page structure
- `styles.css` — styling
- `app.js` — app logic
