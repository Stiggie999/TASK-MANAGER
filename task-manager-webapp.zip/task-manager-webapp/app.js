const STORAGE_KEY = 'taskManagerWebApp_v1';

const seedData = {
  users: ['Unassigned', 'Alex', 'Sam', 'Jordan', 'Taylor'],
  projects: [
    {
      id: crypto.randomUUID(),
      name: 'Website Redesign',
      description: 'Refresh site content and structure.',
      tasks: [
        {
          id: crypto.randomUUID(),
          title: 'Draft homepage copy',
          notes: 'Write a clearer headline and CTA.',
          assignedTo: 'Alex',
          priority: 'High',
          dueDate: '',
          completed: false,
          createdAt: new Date().toISOString()
        },
        {
          id: crypto.randomUUID(),
          title: 'Approve new logo options',
          notes: '',
          assignedTo: 'Jordan',
          priority: 'Medium',
          dueDate: '',
          completed: true,
          createdAt: new Date().toISOString()
        }
      ]
    },
    {
      id: crypto.randomUUID(),
      name: 'Launch Plan',
      description: 'Coordinate launch tasks and deadlines.',
      tasks: []
    }
  ]
};

let state = loadState();
let currentProjectId = null;

const els = {
  homeView: document.getElementById('homeView'),
  projectView: document.getElementById('projectView'),
  homeBtn: document.getElementById('homeBtn'),
  newProjectBtn: document.getElementById('newProjectBtn'),
  projectGrid: document.getElementById('projectGrid'),
  projectCount: document.getElementById('projectCount'),
  projectTitle: document.getElementById('projectTitle'),
  projectMeta: document.getElementById('projectMeta'),
  taskList: document.getElementById('taskList'),
  taskCount: document.getElementById('taskCount'),
  taskForm: document.getElementById('taskForm'),
  taskFormTitle: document.getElementById('taskFormTitle'),
  cancelEditBtn: document.getElementById('cancelEditBtn'),
  editingTaskId: document.getElementById('editingTaskId'),
  taskTitle: document.getElementById('taskTitle'),
  taskNotes: document.getElementById('taskNotes'),
  taskAssignedTo: document.getElementById('taskAssignedTo'),
  taskPriority: document.getElementById('taskPriority'),
  taskDueDate: document.getElementById('taskDueDate'),
  taskCompleted: document.getElementById('taskCompleted'),
  filterStatus: document.getElementById('filterStatus'),
  filterPriority: document.getElementById('filterPriority'),
  filterUser: document.getElementById('filterUser'),
  projectModal: document.getElementById('projectModal'),
  projectForm: document.getElementById('projectForm'),
  projectName: document.getElementById('projectName'),
  projectDescription: document.getElementById('projectDescription'),
  closeProjectModalBtn: document.getElementById('closeProjectModalBtn')
};

function loadState() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return structuredClone(seedData);
  try {
    const parsed = JSON.parse(raw);
    return {
      users: Array.isArray(parsed.users) && parsed.users.length ? parsed.users : structuredClone(seedData.users),
      projects: Array.isArray(parsed.projects) ? parsed.projects : structuredClone(seedData.projects)
    };
  } catch {
    return structuredClone(seedData);
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function getCurrentProject() {
  return state.projects.find(p => p.id === currentProjectId) || null;
}

function showHome() {
  currentProjectId = null;
  els.homeView.classList.add('active');
  els.projectView.classList.remove('active');
  els.homeBtn.classList.add('hidden');
  els.newProjectBtn.classList.remove('hidden');
  resetTaskForm();
  renderProjects();
}

function openProject(projectId) {
  currentProjectId = projectId;
  els.homeView.classList.remove('active');
  els.projectView.classList.add('active');
  els.homeBtn.classList.remove('hidden');
  els.newProjectBtn.classList.add('hidden');
  populateUserSelects();
  resetTaskForm();
  renderProjectView();
}

function populateUserSelects() {
  const userOptions = state.users.map(user => `<option value="${escapeHtml(user)}">${escapeHtml(user)}</option>`).join('');
  els.taskAssignedTo.innerHTML = userOptions;
  els.filterUser.innerHTML = '<option value="all">All Users</option>' + userOptions;
}

function renderProjects() {
  els.projectCount.textContent = `${state.projects.length} project${state.projects.length === 1 ? '' : 's'}`;
  if (!state.projects.length) {
    els.projectGrid.innerHTML = `<div class="empty-state">No projects yet. Tap <strong>New Project</strong> to create your first one.</div>`;
    return;
  }

  els.projectGrid.innerHTML = state.projects.map(project => {
    const completed = project.tasks.filter(t => t.completed).length;
    return `
      <article class="project-card" data-project-id="${project.id}">
        <h3>${escapeHtml(project.name)}</h3>
        <p>${escapeHtml(project.description || 'No description yet.')}</p>
        <div class="project-stats">
          <span>${project.tasks.length} task${project.tasks.length === 1 ? '' : 's'}</span>
          <span>${completed} completed</span>
        </div>
      </article>
    `;
  }).join('');

  document.querySelectorAll('[data-project-id]').forEach(card => {
    card.addEventListener('click', () => openProject(card.dataset.projectId));
  });
}

function renderProjectView() {
  const project = getCurrentProject();
  if (!project) return showHome();

  els.projectTitle.textContent = project.name;
  els.projectMeta.textContent = project.description || 'No description yet.';

  let tasks = [...project.tasks];
  const status = els.filterStatus.value;
  const priority = els.filterPriority.value;
  const user = els.filterUser.value;

  if (status === 'open') tasks = tasks.filter(t => !t.completed);
  if (status === 'done') tasks = tasks.filter(t => t.completed);
  if (priority !== 'all') tasks = tasks.filter(t => t.priority === priority);
  if (user !== 'all') tasks = tasks.filter(t => t.assignedTo === user);

  els.taskCount.textContent = `${tasks.length} task${tasks.length === 1 ? '' : 's'}`;

  if (!tasks.length) {
    els.taskList.innerHTML = '<div class="empty-state">No tasks match your filters yet.</div>';
    return;
  }

  els.taskList.innerHTML = tasks.map(task => `
    <article class="task-card ${task.completed ? 'completed' : ''}">
      <div class="task-top">
        <div>
          <h4>${escapeHtml(task.title)}</h4>
          <p class="task-notes">${escapeHtml(task.notes || 'No notes.')}</p>
        </div>
      </div>
      <div class="badges">
        <span class="badge priority-${escapeHtml(task.priority)}">${escapeHtml(task.priority)}</span>
        <span class="badge">${escapeHtml(task.assignedTo || 'Unassigned')}</span>
        <span class="badge">${task.dueDate ? formatDate(task.dueDate) : 'No due date'}</span>
        <span class="badge">${task.completed ? 'Completed' : 'Open'}</span>
      </div>
      <div class="task-actions">
        <button class="ghost" type="button" data-action="toggle" data-task-id="${task.id}">${task.completed ? 'Mark Open' : 'Mark Done'}</button>
        <button class="ghost" type="button" data-action="edit" data-task-id="${task.id}">Edit</button>
        <button class="danger" type="button" data-action="delete" data-task-id="${task.id}">Delete</button>
      </div>
    </article>
  `).join('');

  document.querySelectorAll('[data-action]').forEach(button => {
    button.addEventListener('click', () => handleTaskAction(button.dataset.action, button.dataset.taskId));
  });
}

function handleTaskAction(action, taskId) {
  const project = getCurrentProject();
  if (!project) return;
  const task = project.tasks.find(t => t.id === taskId);
  if (!task) return;

  if (action === 'toggle') {
    task.completed = !task.completed;
  }

  if (action === 'edit') {
    els.taskFormTitle.textContent = 'Edit Task';
    els.cancelEditBtn.classList.remove('hidden');
    els.editingTaskId.value = task.id;
    els.taskTitle.value = task.title;
    els.taskNotes.value = task.notes;
    els.taskAssignedTo.value = task.assignedTo || 'Unassigned';
    els.taskPriority.value = task.priority;
    els.taskDueDate.value = task.dueDate || '';
    els.taskCompleted.checked = !!task.completed;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  if (action === 'delete') {
    project.tasks = project.tasks.filter(t => t.id !== taskId);
  }

  saveState();
  renderProjects();
  renderProjectView();
}

function resetTaskForm() {
  els.taskForm.reset();
  els.taskFormTitle.textContent = 'Add Task';
  els.editingTaskId.value = '';
  els.cancelEditBtn.classList.add('hidden');
  if (state.users.includes('Unassigned')) {
    els.taskAssignedTo.value = 'Unassigned';
  }
  els.taskPriority.value = 'Medium';
}

function createProject(event) {
  event.preventDefault();
  const name = els.projectName.value.trim();
  const description = els.projectDescription.value.trim();
  if (!name) return;

  const project = {
    id: crypto.randomUUID(),
    name,
    description,
    tasks: []
  };

  state.projects.unshift(project);
  saveState();
  closeProjectModal();
  els.projectForm.reset();
  renderProjects();
  openProject(project.id);
}

function saveTask(event) {
  event.preventDefault();
  const project = getCurrentProject();
  if (!project) return;

  const payload = {
    title: els.taskTitle.value.trim(),
    notes: els.taskNotes.value.trim(),
    assignedTo: els.taskAssignedTo.value,
    priority: els.taskPriority.value,
    dueDate: els.taskDueDate.value,
    completed: els.taskCompleted.checked
  };

  if (!payload.title) return;

  const editingId = els.editingTaskId.value;
  if (editingId) {
    const task = project.tasks.find(t => t.id === editingId);
    if (task) Object.assign(task, payload);
  } else {
    project.tasks.unshift({
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      ...payload
    });
  }

  saveState();
  renderProjects();
  renderProjectView();
  resetTaskForm();
}

function openProjectModal() {
  els.projectModal.classList.remove('hidden');
  els.projectModal.setAttribute('aria-hidden', 'false');
  setTimeout(() => els.projectName.focus(), 0);
}

function closeProjectModal() {
  els.projectModal.classList.add('hidden');
  els.projectModal.setAttribute('aria-hidden', 'true');
}

function formatDate(value) {
  const d = new Date(value + 'T00:00:00');
  return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

function escapeHtml(str) {
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

els.homeBtn.addEventListener('click', showHome);
els.newProjectBtn.addEventListener('click', openProjectModal);
els.closeProjectModalBtn.addEventListener('click', closeProjectModal);
els.projectModal.addEventListener('click', (event) => {
  if (event.target === els.projectModal) closeProjectModal();
});
els.projectForm.addEventListener('submit', createProject);
els.taskForm.addEventListener('submit', saveTask);
els.cancelEditBtn.addEventListener('click', resetTaskForm);
els.filterStatus.addEventListener('change', renderProjectView);
els.filterPriority.addEventListener('change', renderProjectView);
els.filterUser.addEventListener('change', renderProjectView);

populateUserSelects();
showHome();
